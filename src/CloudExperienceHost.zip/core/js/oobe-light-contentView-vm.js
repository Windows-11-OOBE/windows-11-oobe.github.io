﻿//
// Copyright (C) Microsoft. All rights reserved.
//
define(() => {
    class OobeLightContentViewViewModel {
        constructor(params) {
        }
    }
    return OobeLightContentViewViewModel;
});