﻿//
// Copyright (C) Microsoft. All rights reserved.
//
define(() => {
    class DefaultViewModel {
        constructor(frameName) {
            this.frameName = frameName;
        }
    }
    return DefaultViewModel;
});