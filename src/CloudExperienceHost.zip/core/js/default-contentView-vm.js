﻿//
// Copyright (C) Microsoft. All rights reserved.
//
define(() => {
    class DefaultContentViewViewModel {
        constructor(params) {
            //TODO: add data binding  (https://microsoft.visualstudio.com/OS/_workitems?id=8705838&_a=edit) 
        }
    }
    return DefaultContentViewViewModel;
});